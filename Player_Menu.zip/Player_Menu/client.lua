local display = false
local godMode = false
local noclip = false
local blips = false
local nametags = false
local superJump = false
local fastRun = false
local fastSwim = false
local showSpeedometer = false
local unlimitedStamina = false


-- Vehicle configurations
local vehicleConfigs = {}
local enginePowerLevels = {1.0, 1.5, 2.0, 2.5}
local tractionLevels = {0.5, 1.0, 1.5, 2.0}
local tractionLossLevels = {1.0, 0.8, 0.6, 0.4}
local lowSpeedTractionLevels = {1.0, 0.8, 0.6, 0.4}
local brakePowerLevels = {1.0, 1.5, 2.0, 2.5}
local handBrakeLevels = {0.5, 1.0, 1.5, 2.0}

-- Vehicle handling multipliers
local vehicleHandling = {
    enginePower = {1.0, 1.25, 1.5, 1.75, 2.0},
    brakePower = {1.0, 1.25, 1.5, 1.75},
    transmission = {1.0, 1.15, 1.25, 1.35},
    suspension = {0.0, -0.05, -0.1, -0.15, -0.2}
}

RegisterKeyMapping('pmenu', 'Toggle Player Menu', 'keyboard', 'M')

RegisterCommand('pmenu', function()
    if not display then
        display = true
        SetNuiFocus(true, true)
        SetNuiFocusKeepInput(true)
        DisableIdleCamera(true)
        
        CreateThread(function()
            while display do
                DisableControlAction(0, 1, true)
                DisableControlAction(0, 2, true)
                DisableControlAction(0, 24, true)
                DisableControlAction(0, 257, true)
                DisableControlAction(0, 25, true)
                DisableControlAction(0, 263, true)
                Wait(0)
            end
        end)
        
        SendNUIMessage({
            type = "ui",
            status = true
        })
    else
        display = false
        SetNuiFocus(false, false)
        DisableIdleCamera(false)
        
        EnableControlAction(0, 1, true)
        EnableControlAction(0, 2, true)
        EnableControlAction(0, 24, true)
        EnableControlAction(0, 257, true)
        EnableControlAction(0, 25, true)
        EnableControlAction(0, 263, true)
        
        SendNUIMessage({
            type = "ui",
            status = false
        })
    end
end)

-- Player Options
RegisterNUICallback('toggleGodMode', function(data, cb)
    godMode = not godMode
    SetEntityInvincible(PlayerPedId(), godMode)
    cb({status = godMode})
end)

RegisterNUICallback('healPlayer', function(data, cb)
    SetEntityHealth(PlayerPedId(), 200)
    cb('ok')
end)

RegisterNUICallback('toggleNoclip', function(data, cb)
    noclip = not noclip
    local ped = PlayerPedId()
    if noclip then
        SetEntityCollision(ped, false, false)
        SetEntityVisible(ped, false, false)
    else
        SetEntityCollision(ped, true, true)
        SetEntityVisible(ped, true, false)
    end
    cb({status = noclip})
end)

RegisterNUICallback('toggleBlips', function(data, cb)
    blips = not blips
    if blips then
        CreatePlayerBlips()
    else
        RemovePlayerBlips()
    end
    cb({status = blips})
end)

RegisterNUICallback('toggleNametags', function(data, cb)
    nametags = not nametags
    cb({status = nametags})
end)

RegisterNUICallback('toggleSuperJump', function(data, cb)
    superJump = not superJump
    SetPedConfigFlag(PlayerPedId(), 60, superJump)
    cb({status = superJump})
end)

RegisterNUICallback('toggleFastRun', function(data, cb)
    fastRun = not fastRun
    SetRunSprintMultiplierForPlayer(PlayerId(), fastRun and 1.49 or 1.0)
    cb({status = fastRun})
end)

RegisterNUICallback('toggleFastSwim', function(data, cb)
    fastSwim = not fastSwim
    SetSwimMultiplierForPlayer(PlayerId(), fastSwim and 1.49 or 1.0)
    cb({status = fastSwim})
end)

-- Vehicle Functions
RegisterNUICallback('spawnVehicle', function(data, cb)
    local model = GetHashKey(data.vehicle)
    RequestModel(model)
    while not HasModelLoaded(model) do
        Wait(0)
    end
    
    local ped = PlayerPedId()
    local pos = GetEntityCoords(ped)
    local vehicle = CreateVehicle(model, pos.x, pos.y, pos.z, GetEntityHeading(ped), true, false)
    SetPedIntoVehicle(ped, vehicle, -1)
    SetModelAsNoLongerNeeded(model)
    cb('ok')
end)

RegisterNUICallback('toggleSpeedometer', function(data, cb)
    showSpeedometer = not showSpeedometer
    cb('ok')
end)

-- Speedometer display thread
Citizen.CreateThread(function()
    while true do
        Citizen.Wait(0)
        if showSpeedometer and IsPedInAnyVehicle(PlayerPedId(), false) then
            local vehicle = GetVehiclePedIsIn(PlayerPedId(), false)
            local speed = GetEntitySpeed(vehicle) * 2.236936 -- Convert to MPH
            
            SetTextFont(4)
            SetTextScale(0.5, 0.5)
            SetTextColour(255, 255, 255, 255)
            SetTextDropshadow(0, 0, 0, 0, 255)
            SetTextEdge(1, 0, 0, 0, 255)
            SetTextDropShadow()
            SetTextOutline()
            SetTextEntry("STRING")
            AddTextComponentString(math.floor(speed) .. " MPH")
            DrawText(0.87, 0.95)
        end
    end
end)

RegisterNUICallback('applyVehicleMods', function(data, cb)
    local vehicle = GetVehiclePedIsIn(PlayerPedId(), false)
    if vehicle == 0 then return end

    -- Apply engine mods
    SetVehicleModKit(vehicle, 0)
    SetVehicleMod(vehicle, 11, data.engine, false)
    SetVehicleMod(vehicle, 13, data.transmission, false)
    SetVehicleMod(vehicle, 12, data.brakes, false)
    SetVehicleMod(vehicle, 15, data.suspension, false)
    SetVehicleMod(vehicle, 18, data.turbo, false)

    -- Apply handling modifications
    SetVehicleEnginePowerMultiplier(vehicle, vehicleHandling.enginePower[data.engine + 1])
    SetVehicleHandlingFloat(vehicle, "CHandlingData", "fBrakeForce", vehicleHandling.brakePower[data.brakes + 1])
    SetVehicleHandlingFloat(vehicle, "CHandlingData", "fDriveInertia", vehicleHandling.transmission[data.transmission + 1])
    SetVehicleHandlingFloat(vehicle, "CHandlingData", "fSuspensionRaise", vehicleHandling.suspension[data.suspension + 1])

    -- Force handling update
    ModifyVehicleTopSpeed(vehicle, vehicleHandling.enginePower[data.engine + 1])

    cb('ok')
end)

-- Appearance Components
local appearanceComponents = {
    face = {overlayId = 0, maxValues = 45},
    hair = {componentId = 2, maxValues = 73, textures = 63},
    beard = {overlayId = 1, maxValues = 28, textures = 63},
    eyebrows = {overlayId = 2, maxValues = 33, textures = 63},
    aging = {overlayId = 3, maxValues = 14},
    makeup = {overlayId = 4, maxValues = 74},
    blush = {overlayId = 5, maxValues = 32},
    complexion = {overlayId = 6, maxValues = 11},
    sundamage = {overlayId = 7, maxValues = 10},
    lipstick = {overlayId = 8, maxValues = 9},
    freckles = {overlayId = 9, maxValues = 17},
    chest = {overlayId = 10, maxValues = 16},
    bodymarks = {overlayId = 11, maxValues = 11},
    torso = {componentId = 3, maxValues = 196, textures = 16},
    tops = {componentId = 11, maxValues = 289, textures = 16},
    undershirt = {componentId = 8, maxValues = 171, textures = 16},
    pants = {componentId = 4, maxValues = 114, textures = 16},
    shoes = {componentId = 6, maxValues = 91, textures = 16},
    accessories = {componentId = 7, maxValues = 148, textures = 16},
    masks = {componentId = 1, maxValues = 197, textures = 16}
}

RegisterNUICallback('setAppearance', function(data, cb)
    local ped = PlayerPedId()
    local category = data.category
    local value = tonumber(data.value)
    local textureValue = tonumber(data.texture) or 0
    
    if appearanceComponents[category].componentId then
        SetPedComponentVariation(ped, appearanceComponents[category].componentId, value, textureValue, 0)
    elseif appearanceComponents[category].overlayId then
        SetPedHeadOverlay(ped, appearanceComponents[category].overlayId, value, 1.0)
        if textureValue > 0 then
            SetPedHeadOverlayColor(ped, appearanceComponents[category].overlayId, 1, textureValue, textureValue)
        end
    end
    
    cb('ok')
end)

RegisterNUICallback('changePedModel', function(data, cb)
    local model = GetHashKey(data.model)
    
    RequestModel(model)
    while not HasModelLoaded(model) do
        Wait(0)
    end
    
    SetPlayerModel(PlayerId(), model)
    SetModelAsNoLongerNeeded(model)
    
    -- If switching to MP model, initialize face features
    if data.model == "mp_m_freemode_01" or data.model == "mp_f_freemode_01" then
        SetPedDefaultComponentVariation(PlayerPedId())
    end
    
    cb('ok')
end)

RegisterNUICallback('selfDetonate', function(data, cb)
    local ped = PlayerPedId()
    local coords = GetEntityCoords(ped)
    
    -- Make player temporarily invincible during explosion
    SetEntityInvincible(ped, true)
    
    -- Create massive explosion
    AddExplosion(coords.x, coords.y, coords.z, 7, 100.0, true, false, 3.0)
    
    -- Small delay before removing invincibility
    Citizen.Wait(1000)
    SetEntityInvincible(ped, false)
    
    cb('ok')
end)

-- Player Blips Functions
function CreatePlayerBlips()
    Citizen.CreateThread(function()
        while blips do
            local players = GetActivePlayers()
            for _, player in ipairs(players) do
                local ped = GetPlayerPed(player)
                if not DoesBlipExist(GetBlipFromEntity(ped)) then
                    local blip = AddBlipForEntity(ped)
                    SetBlipSprite(blip, 1)
                    SetBlipColour(blip, 0)
                    SetBlipScale(blip, 0.85)
                    SetBlipAsShortRange(blip, true)
                end
            end
            Citizen.Wait(1000)
        end
    end)
end

function RemovePlayerBlips()
    local players = GetActivePlayers()
    for _, player in ipairs(players) do
        local ped = GetPlayerPed(player)
        local blip = GetBlipFromEntity(ped)
        if DoesBlipExist(blip) then
            RemoveBlip(blip)
        end
    end
end

-- Nametags Display
Citizen.CreateThread(function()
    while true do
        Citizen.Wait(0)
        if nametags then
            local players = GetActivePlayers()
            for _, player in ipairs(players) do
                local ped = GetPlayerPed(player)
                if ped ~= PlayerPedId() then
                    local coords = GetEntityCoords(ped)
                    local distance = #(GetEntityCoords(PlayerPedId()) - coords)
                    if distance < 20 then
                        DrawText3D(coords.x, coords.y, coords.z + 1.0, GetPlayerName(player))
                    end
                end
            end
        end
    end
end)

function DrawText3D(x, y, z, text)
    local onScreen, _x, _y = World3dToScreen2d(x, y, z)
    if onScreen then
        SetTextScale(0.35, 0.35)
        SetTextFont(4)
        SetTextProportional(1)
        SetTextColour(255, 255, 255, 215)
        SetTextEntry("STRING")
        SetTextCentre(1)
        AddTextComponentString(text)
        DrawText(_x, _y)
    end
end

-- Noclip Movement
Citizen.CreateThread(function()
    while true do
        Citizen.Wait(0)
        if noclip then
            local ped = PlayerPedId()
            local x, y, z = table.unpack(GetEntityCoords(ped, true))
            local camRot = GetGameplayCamRot(2)
            local camHeading = math.rad(camRot.z)
            local speed = 0.5
            
            if IsControlPressed(0, 32) then -- W key
                x = x + (math.sin(-camHeading) * speed)
                y = y + (math.cos(-camHeading) * speed)
            end
            if IsControlPressed(0, 33) then -- S key
                x = x - (math.sin(-camHeading) * speed)
                y = y - (math.cos(-camHeading) * speed)
            end
            if IsControlPressed(0, 34) then -- A key
                x = x - (math.cos(-camHeading) * speed)
                y = y + (math.sin(-camHeading) * speed)
            end
            if IsControlPressed(0, 35) then -- D key
                x = x + (math.cos(-camHeading) * speed)
                y = y - (math.sin(-camHeading) * speed)
            end
            if IsControlPressed(0, 22) then -- Space
                z = z + speed
            end
            if IsControlPressed(0, 36) then -- Left Ctrl
                z = z - speed
            end
            
            SetEntityCoordsNoOffset(ped, x, y, z, true, true, true)
        end
        
        if superJump then
            SetSuperJumpThisFrame(PlayerId())
        end
    end
end)

RegisterNUICallback('toggleUnlimitedStamina', function(data, cb)
    unlimitedStamina = not unlimitedStamina
    
    if unlimitedStamina then
        StatSetInt('MP0_STAMINA', 100, true)
    end
    
    CreateThread(function()
        while unlimitedStamina do
            RestorePlayerStamina(PlayerId(), 1.0)
            Wait(0)
        end
    end)
    
    cb({status = unlimitedStamina})
end)

