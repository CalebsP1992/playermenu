fx_version 'cerulean'
game 'gta5'

author 'PlayDough'
description 'Advanced Player Menu with Appearance and Vehicle Options'
version '2.5.8'

client_scripts {
    'client.lua'
}

ui_page 'html/index.html'

files {
    'html/index.html',
    'html/style.css',
    'html/script.js'
}

server_script {
    'version.lua'
}