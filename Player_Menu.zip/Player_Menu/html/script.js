let display = false;


// Main display handling
window.addEventListener('message', function(event) {
    if (event.data.type === "ui") {
        display = event.data.status;
        document.getElementById('player-menu').style.display = display ? "block" : "none";
        if(display) {
            showSection('player'); // Default to player section when opening
        }
    }
});

function showSection(sectionName) {
    const sections = document.querySelectorAll('.menu-section');
    sections.forEach(section => section.style.display = 'none');
    document.getElementById(sectionName).style.display = 'block';
}

// Vehicle list population
const vehicles = [
    "adder", "zentorno", "t20", "kuruma", "insurgent", "buffalo", "comet", "banshee",
    "sultan", "exemplar", "f620", "felon", "sentinel", "blade", "buccaneer", "phoenix",
    "dominator", "gauntlet", "vigero", "sandking", "rebel", "blazer", "bati", "double",
    "hexer", "nemesis", "pcj", "ruffian", "sanchez", "vader"
];

// Populate vehicle dropdown
const vehicleSelect = document.getElementById('vehicle-select');
vehicles.forEach(vehicle => {
    const option = document.createElement('option');
    option.value = vehicle;
    option.textContent = vehicle.charAt(0).toUpperCase() + vehicle.slice(1);
    vehicleSelect.appendChild(option);
});

const appearanceComponents = {
    face: { max: 45, textures: 1 },
    hair: { max: 73, textures: 63 },
    beard: { max: 28, textures: 63 },
    eyebrows: { max: 33, textures: 63 },
    aging: { max: 14, textures: 1 },
    makeup: { max: 74, textures: 63 },
    blush: { max: 32, textures: 63 },
    complexion: { max: 11, textures: 1 },
    sundamage: { max: 10, textures: 1 },
    lipstick: { max: 9, textures: 63 },
    freckles: { max: 17, textures: 1 },
    chest: { max: 16, textures: 1 },
    bodymarks: { max: 11, textures: 1 },
    torso: { max: 196, textures: 16 },
    tops: { max: 289, textures: 16 },
    undershirt: { max: 171, textures: 16 },
    pants: { max: 114, textures: 16 },
    shoes: { max: 91, textures: 16 },
    accessories: { max: 148, textures: 16 },
    masks: { max: 197, textures: 16 }
};

let currentAppearance = {};

// Initialize all appearance values
Object.keys(appearanceComponents).forEach(component => {
    currentAppearance[component] = {
        value: 0,
        texture: 0
    };
});

function cycleAppearance(component, direction, isTexture = false) {
    if (!appearanceComponents[component]) return;

    const maxValue = isTexture ? 
        appearanceComponents[component].textures : 
        appearanceComponents[component].max;
    
    const key = isTexture ? 'texture' : 'value';
    
    if (direction === 'next') {
        currentAppearance[component][key] = (currentAppearance[component][key] + 1) % maxValue;
    } else {
        currentAppearance[component][key]--;
        if (currentAppearance[component][key] < 0) {
            currentAppearance[component][key] = maxValue - 1;
        }
    }
    
    // Update UI
    document.getElementById(`${component}-${key}`).textContent = currentAppearance[component][key];
    
    // Send to client
    fetch(`https://${GetParentResourceName()}/setAppearance`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            category: component,
            value: currentAppearance[component].value,
            texture: currentAppearance[component].texture
        })
    });
}

// Player Options
function toggleGodMode() {
    fetch(`https://${GetParentResourceName()}/toggleGodMode`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({})
    });
}

function healPlayer() {
    fetch(`https://${GetParentResourceName()}/healPlayer`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({})
    });
}

function toggleNoclip() {
    fetch(`https://${GetParentResourceName()}/toggleNoclip`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({})
    });
}

function toggleBlips() {
    fetch(`https://${GetParentResourceName()}/toggleBlips`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({})
    });
}

function toggleNametags() {
    fetch(`https://${GetParentResourceName()}/toggleNametags`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({})
    });
}

function toggleSuperJump() {
    fetch(`https://${GetParentResourceName()}/toggleSuperJump`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({})
    });
}

function toggleFastRun() {
    fetch(`https://${GetParentResourceName()}/toggleFastRun`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({})
    });
}

function toggleFastSwim() {
    fetch(`https://${GetParentResourceName()}/toggleFastSwim`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({})
    });
}

function spawnVehicle() {
    const vehicle = document.getElementById('vehicle-select').value;
    fetch(`https://${GetParentResourceName()}/spawnVehicle`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            vehicle: vehicle
        })
    });
}

function changePedModel() {
    const model = document.getElementById('ped-select').value;
    fetch(`https://${GetParentResourceName()}/changePedModel`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            model: model
        })
    });
}

function updateButtonState(buttonElement, active) {
    if (active) {
        buttonElement.classList.add('active');
    } else {
        buttonElement.classList.remove('active');
    }
}

// Update the toggle functions
function toggleGodMode() {
    fetch(`https://${GetParentResourceName()}/toggleGodMode`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({})
    }).then(resp => resp.json()).then(resp => {
        updateButtonState(document.querySelector('button[onclick="toggleGodMode()"]'), resp.status);
    });
}

function toggleNoclip() {
    fetch(`https://${GetParentResourceName()}/toggleNoclip`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({})
    }).then(resp => resp.json()).then(resp => {
        updateButtonState(document.querySelector('button[onclick="toggleNoclip()"]'), resp.status);
    });
}

function toggleBlips() {
    fetch(`https://${GetParentResourceName()}/toggleBlips`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({})
    }).then(resp => resp.json()).then(resp => {
        updateButtonState(document.querySelector('button[onclick="toggleBlips()"]'), resp.status);
    });
}

function toggleNametags() {
    fetch(`https://${GetParentResourceName()}/toggleNametags`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({})
    }).then(resp => resp.json()).then(resp => {
        updateButtonState(document.querySelector('button[onclick="toggleNametags()"]'), resp.status);
    });
}

function toggleSuperJump() {
    fetch(`https://${GetParentResourceName()}/toggleSuperJump`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({})
    }).then(resp => resp.json()).then(resp => {
        updateButtonState(document.querySelector('button[onclick="toggleSuperJump()"]'), resp.status);
    });
}

function toggleFastRun() {
    fetch(`https://${GetParentResourceName()}/toggleFastRun`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({})
    }).then(resp => resp.json()).then(resp => {
        updateButtonState(document.querySelector('button[onclick="toggleFastRun()"]'), resp.status);
    });
}

function toggleFastSwim() {
    fetch(`https://${GetParentResourceName()}/toggleFastSwim`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({})
    }).then(resp => resp.json()).then(resp => {
        updateButtonState(document.querySelector('button[onclick="toggleFastSwim()"]'), resp.status);
    });
}

function toggleSpeedometer() {
    fetch(`https://${GetParentResourceName()}/toggleSpeedometer`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({})
    }).then(resp => resp.json()).then(resp => {
        updateButtonState(document.querySelector('button[onclick="toggleSpeedometer()"]'), resp.status);
    });
}

function toggleSpeedometer() {
    fetch(`https://${GetParentResourceName()}/toggleSpeedometer`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({})
    }).then(resp => resp.json()).then(resp => {
        updateButtonState(document.querySelector('button[onclick="toggleSpeedometer()"]'), resp.status);
    });
}

function applyVehicleMods() {
    const mods = {
        engine: parseInt(document.getElementById('enginePower').value),
        transmission: parseInt(document.getElementById('transmission').value),
        brakes: parseInt(document.getElementById('brakes').value),
        suspension: parseInt(document.getElementById('suspension').value),
        turbo: parseInt(document.getElementById('turbo').value)
    };

    fetch(`https://${GetParentResourceName()}/applyVehicleMods`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(mods)
    });
}

function selfDetonate() {
    fetch(`https://${GetParentResourceName()}/selfDetonate`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({})
    });
}

// Close menu with ESC
document.onkeyup = function(event) {
    if (event.key === 'Escape') {
        const sections = document.querySelectorAll('.menu-section');
        sections.forEach(section => section.style.display = 'none');
        document.getElementById('player-menu').style.display = 'none';
        
        fetch(`https://${GetParentResourceName()}/close`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({})
        });
    }
};


function initSpeedometer() {
    speedCanvas = document.getElementById('speedometer');
    speedCtx = speedCanvas.getContext('2d');
    
    // Set canvas size with better resolution
    speedCanvas.width = 400;
    speedCanvas.height = 400;
}

function drawSpeedometer(speed) {
    const centerX = speedCanvas.width / 2;
    const centerY = speedCanvas.height / 2;
    const radius = centerX - 40;

    // Clear canvas
    speedCtx.clearRect(0, 0, speedCanvas.width, speedCanvas.height);

    // Draw outer circle
    speedCtx.beginPath();
    speedCtx.arc(centerX, centerY, radius, 0, 2 * Math.PI);
    speedCtx.strokeStyle = '#3498db';
    speedCtx.lineWidth = 10;
    speedCtx.stroke();

    // Draw speed markings
    for (let i = 0; i <= 120; i += 10) {
        const angle = (i / 120) * Math.PI + Math.PI;
        const startRadius = radius - 20;
        const endRadius = radius - (i % 20 === 0 ? 40 : 30);
        
        speedCtx.beginPath();
        speedCtx.moveTo(
            centerX + startRadius * Math.cos(angle),
            centerY + startRadius * Math.sin(angle)
        );
        speedCtx.lineTo(
            centerX + endRadius * Math.cos(angle),
            centerY + endRadius * Math.sin(angle)
        );
        speedCtx.strokeStyle = '#fff';
        speedCtx.lineWidth = i % 20 === 0 ? 3 : 1;
        speedCtx.stroke();

        if (i % 20 === 0) {
            speedCtx.font = '20px Arial';
            speedCtx.fillStyle = '#fff';
            speedCtx.textAlign = 'center';
            speedCtx.fillText(
                i.toString(),
                centerX + (endRadius - 25) * Math.cos(angle),
                centerY + (endRadius - 25) * Math.sin(angle)
            );
        }
    }

    // Draw needle
    const needleAngle = ((Math.min(speed, 120) / 120) * Math.PI + Math.PI);
    speedCtx.beginPath();
    speedCtx.moveTo(centerX, centerY);
    speedCtx.lineTo(
        centerX + (radius - 60) * Math.cos(needleAngle),
        centerY + (radius - 60) * Math.sin(needleAngle)
    );
    speedCtx.strokeStyle = '#e74c3c';
    speedCtx.lineWidth = 4;
    speedCtx.stroke();

    // Draw center circle
    speedCtx.beginPath();
    speedCtx.arc(centerX, centerY, 10, 0, 2 * Math.PI);
    speedCtx.fillStyle = '#e74c3c';
    speedCtx.fill();

    // Draw speed text
    speedCtx.font = 'bold 30px Arial';
    speedCtx.fillStyle = '#fff';
    speedCtx.textAlign = 'center';
    speedCtx.fillText(Math.floor(speed) + ' MPH', centerX, centerY + 60);
}

function toggleUnlimitedStamina() {
    fetch(`https://${GetParentResourceName()}/toggleUnlimitedStamina`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({})
    }).then(resp => resp.json()).then(resp => {
        updateButtonState(document.querySelector('button[onclick="toggleUnlimitedStamina()"]'), resp.status);
    });
}

