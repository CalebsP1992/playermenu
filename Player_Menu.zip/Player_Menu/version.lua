local function OnResourceStart(resourceName)
    if (GetCurrentResourceName() ~= resourceName) then
        return
    end
    print('^4')
    print([[
                        PPPPPPPPPPP      MMMM       MMMM
                        PPPPPPPPPPPP     MMMMM     MMMMM
                        PPP      PPPP    MMMMMM   MMMMMM
                        PPP      PPPP    MMMMMMM MMMMMMM
                        PPPPPPPPPPPP     MMM MMM MMM MMM
                        PPPPPPPPPPP      MMM  MMMMM  MMM
                        PPP              MMM   MMM   MMM
                        PPP              MMM         MMM
                        PPP              MMM         MMM
                        PPP              MMM         MMM
    ]])
    print([[
                            Player Menu v2.5.8
                               Up to date
    ]])
end

AddEventHandler('onResourceStart', OnResourceStart)
